"use client";

import Image from "next/image";
import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function MerchNavbar() {
  const [currency, setCurrency] = useState("USD");

  return (
    <nav className="bg-black text-white w-full">
      <div className="max-w-7xl mx-auto px-8 py-3 flex items-center justify-between">
        {/* Logos */}
        <div className="flex items-center space-x-6">
          <Image src="/sonic-logo.svg" alt="Sonic Logo" width={120} height={40} className="h-10 w-auto" style={{ height: 40, width: 'auto' }} />
          <div className="h-8 w-px bg-gray-600 mx-2" />
          <Image src="/images/merch/Gasly-logo.svg" alt="Gasly Logo" height={40} width={120} style={{ height: 40, width: 'auto' }} />
        </div>
        {/* Right side: currency, user, cart */}
        <div className="flex items-center space-x-8">
          <Select value={currency} onValueChange={setCurrency}>
            <SelectTrigger className="w-[70px] bg-transparent border-gray-600 text-white">
              <SelectValue placeholder="USD" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="USD">USD</SelectItem>
              <SelectItem value="EUR">EUR</SelectItem>
              <SelectItem value="GBP">GBP</SelectItem>
            </SelectContent>
          </Select>
          <Image src="/images/merch/User.svg" alt="User Account" width={24} height={24} className="ml-2" />
          <Image src="/images/merch/cart.svg" alt="Cart" width={24} height={24} className="ml-2" />
        </div>
      </div>
    </nav>
  );
} 